import './box.css'
export default function Box3() {

    // state = {  } 
   
        return (
            <div className="card3">
                Component 3
            </div>
        );
    
}
 
// export default Box;