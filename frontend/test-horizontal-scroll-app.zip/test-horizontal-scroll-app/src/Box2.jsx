import './box.css'
export default function Box2() {

    // state = {  } 
   
        return (
            <div className="card2">
                Component 2
            </div>
        );
    
}
 
// export default Box;