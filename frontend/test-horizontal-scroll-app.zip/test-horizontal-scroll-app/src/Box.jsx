import './box.css'
export default function Box() {

    // state = {  } 
   
        return (
            <div className="card">
              Component 1
            </div>
        );
    
}
 
// export default Box;