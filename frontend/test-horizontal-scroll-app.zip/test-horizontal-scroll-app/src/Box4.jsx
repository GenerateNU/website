import './box.css'
export default function Box() {

    // state = {  } 
   
        return (
            <div className="card4">
                Component 4
            </div>
        );
    
}
 
// export default Box;